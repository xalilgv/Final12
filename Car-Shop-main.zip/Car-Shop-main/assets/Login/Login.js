function slide() {
    var cont = document.querySelector(".container");
    cont.innerHTML = `<div class="signup">
      <div class="content2">
        <h1>Create Account</h1>
      <form>
      <div class="username">
        <input type="text" placeholder="username" required>
      </div>
      <div class="password">
        <input type="text" placeholder="email" required>
      </div>
      <div class="password">
        <input type="text" placeholder="password" required>
      </div>
      <div class="password">
        <input type="text" placeholder="confirm password" required>
      </div>
      <div class="btn-container">
        <button type="submit" value="Submit"class="login-btn">
          Create Account
        </button>
      </div>
        </form>
      <div class="options">
        Already Have an Account? <a onclick="">Login</a>
      </div>
      </div>
    </div>
    </div>`
    gsap.to(".login", { x: 380, duration: 2 });
    gsap.to(".content", { opacity: 0 });
    gsap.to(".login", {delay: 2, opacity: 0})
    gsap.to(".signin", { duration: 1, opacity: 0});
    //gsap.to(".login", { delay: 5, duration: 2, opacity: 1 });
    gsap.to(".content2", {delay: 2, duration: 2, opacity: 1});
    gsap.to(".signup", { delay: 2, duration: 2, opacity: 1 });
    gsap.to(".login", {delay: 2.5, duration: 1, x: -380});
  }
  /*
  var cont = document.getElementById("login");
  cont.innerHTML = `<div class="content">
        <h1>Login</h1>
      <div class="username">
        <input type="text" placeholder="username">
      </div>
      <div class="password">
        <input type="text" placeholder="password">
        <p>Forgot Password?</p>
      </div>
      <div class="btn-container">
        <button class="login-btn">
          Login
        </button>
      </div>
      </div>`;*/
  function fade () {
    gsap.to(".content", {duration: 2, opacity: 0});
    gsap.to(".content", {delay: 2, duration: 2, opacity: 1});
  }