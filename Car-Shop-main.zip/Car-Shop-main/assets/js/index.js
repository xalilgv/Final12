const menuBtn = document.querySelector('.menu-btn');
const header_logo_link_menu = document.querySelector('.header_logo_link_menu');
const header = document.getElementById('header');
const body = document.querySelector('body')
header_logo_link_menu.style.transform = "translateY(0px)";
let menuOpen = false;


menuBtn.addEventListener('click', () => {
    if (!menuOpen) {
        menuBtn.classList.add('open');
        // header_logo_link_menu.style.display = "block";
        header_logo_link_menu.style.visibility = "visible";
        header_logo_link_menu.style.opacity = 1;
        header_logo_link_menu.style.transform = "translateY(60px)";
        menuOpen = true;
        document.addEventListener('click', function handleClickOutsideBox(e) {
  
            if (!menuBtn.contains(e.target) && !header_logo_link_menu.contains(e.target)) {
                menuBtn.classList.remove('open');
                // header_logo_link_menu.style.display = "none";
                
                header_logo_link_menu.style.transform = "translateY(0px)";
                header_logo_link_menu.style.visibility = "hidden";
                header_logo_link_menu.style.opacity = 0;
                menuOpen = false;
            }
        });
    } else {
        menuBtn.classList.remove('open');
        // header_logo_link_menu.style.display = "none";
        
        header_logo_link_menu.style.transform = "translateY(0px)";
        header_logo_link_menu.style.visibility = "hidden";
        header_logo_link_menu.style.opacity = 0;
        menuOpen = false;
        
    }
});


const header_searchDiv = document.querySelector('.header_searchDiv');
const header_searchInput = document.getElementById('header_searchInput');
const SearchInputLi = document.querySelector('.SearchInputLi');

header_searchDiv.addEventListener('click',() => {
    header_searchDiv.classList.add('hovered');
    header_searchInput.focus();
    SearchInputLi.style.visibility = "visible";
    SearchInputLi.style.opacity = 1;
    SearchInputLi.classList.remove('d-none')
    document.addEventListener('click', function handleClickOutsideBox(e) {
        if (!header_searchDiv.contains(e.target) && !header_searchInput.contains(e.target) && !SearchInputLi.contains(e.target)) {
            header_searchDiv.classList.remove('hovered');
            SearchInputLi.style.visibility = "hidden";
            SearchInputLi.style.opacity = 0;
            SearchInputLi.classList.add('d-none')
        }
    });
});

const dark_mode = document.getElementById('dark_mode');
const SecondHeaderLine = document.querySelector('.SecondHeaderLine');
let darkMode = false;

dark_mode.addEventListener('click',() => {
    if (!darkMode) {
        SecondHeaderLine.style.backgroundColor = "#4d4d4d";
        

        darkMode = true;
    }
    else{
        SecondHeaderLine.style.backgroundColor = "#DB3727";
        darkMode = false;
    }

});





const All_brands_btn_Show = document.getElementById('All_brands_btn_Show');
const Top_Cars_List_ul = document.getElementById('Top_Cars_List_ul');
const Top_Cars_List_All_Cars =document.getElementById('Top_Cars_List_All_Cars');
const Top_Cars_List_All_Catalog_h4 = document.getElementById('Top_Cars_List_All_Catalog_h4');
const Top_Cars_List_All_Catalog= document.getElementById('Top_Cars_List_All_Catalog');
const All_brands_btn_Hide = document.getElementById('All_brands_btn_Hide');

All_brands_btn_Show.addEventListener('click', () => {
        Top_Cars_List_ul.classList.add('d-none');
        
        Top_Cars_List_All_Cars.classList.remove('d-none');
        Top_Cars_List_All_Catalog_h4.classList.remove('d-none');
        Top_Cars_List_All_Catalog.classList.remove('d-none');
});
All_brands_btn_Hide.addEventListener('click', () => {
    Top_Cars_List_ul.classList.remove('d-none');
        
        Top_Cars_List_All_Cars.classList.add('d-none');
        Top_Cars_List_All_Catalog_h4.classList.add('d-none');
        Top_Cars_List_All_Catalog.classList.add('d-none');
});




//#region Filter Car Price Start

$('.slider').each(function(e) {

    var slider = $(this),
        width = slider.width(),
        handle,
        handleObj;

    let svg = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
    svg.setAttribute('viewBox', '0 0 ' + width + ' 83');

    slider.html(svg);
    slider.append($('<div>').addClass('active').html(svg.cloneNode(true)));

    slider.slider({
        range: true,
        values: [500, 5000000],
        min: 500,
        step: 5500,
        minRange: 1000,
        max: 5004000,
        create(event, ui) {

            slider.find('.ui-slider-handle').append($('<div />'));

            $(slider.data('value-0')).html(slider.slider('values', 0).toString().replace(/\B(?=(\d{3})+(?!\d))/g, '&thinsp;'));
            $(slider.data('value-1')).html(slider.slider('values', 1).toString().replace(/\B(?=(\d{3})+(?!\d))/g, '&thinsp;'));
            $(slider.data('range')).html((slider.slider('values', 1) - slider.slider('values', 0)).toString().replace(/\B(?=(\d{3})+(?!\d))/g, '&thinsp;'));

            setCSSVars(slider);

        },
        start(event, ui) {

            $('body').addClass('ui-slider-active');

            handle = $(ui.handle).data('index', ui.handleIndex);
            handleObj = slider.find('.ui-slider-handle');

        },
        change(event, ui) {
            setCSSVars(slider);
        },
        slide(event, ui) {

            let min = slider.slider('option', 'min'),
                minRange = slider.slider('option', 'minRange'),
                max = slider.slider('option', 'max');

            if(ui.handleIndex == 0) {
                if((ui.values[0] + minRange) >= ui.values[1]) {
                    slider.slider('values', 1, ui.values[0] + minRange);
                }
                if(ui.values[0] > max - minRange) {
                    return false;
                }
            } else if(ui.handleIndex == 1) {
                if((ui.values[1] - minRange) <= ui.values[0]) {
                    slider.slider('values', 0, ui.values[1] - minRange);
                }
                if(ui.values[1] < min + minRange) {
                    return false;
                }
            }

            $(slider.data('value-0')).html(ui.values[0].toString().replace(/\B(?=(\d{3})+(?!\d))/g, '&thinsp;'));
            $(slider.data('value-1')).html(ui.values[1].toString().replace(/\B(?=(\d{3})+(?!\d))/g, '&thinsp;'));
            $(slider.data('range')).html((slider.slider('values', 1) - slider.slider('values', 0)).toString().replace(/\B(?=(\d{3})+(?!\d))/g, '&thinsp;'));

            setCSSVars(slider);

        },
        stop(event, ui) {

            $('body').removeClass('ui-slider-active');

            let duration = .6,
                ease = Elastic.easeOut.config(1.08, .44);

            TweenMax.to(handle, duration, {
                '--y': 0,
                ease: ease
            });

            TweenMax.to(svgPath, duration, {
                y: 42,
                ease: ease
            });

            handle = null;

        }
    });

    var svgPath = new Proxy({
        x: null,
        y: null,
        b: null,
        a: null
    }, {
        set(target, key, value) {
            target[key] = value;
            if(target.x !== null && target.y !== null && target.b !== null && target.a !== null) {
                slider.find('svg').html(getPath([target.x, target.y], target.b, target.a, width));
            }
            return true;
        },
        get(target, key) {
            return target[key];
        }
    });

    svgPath.x = width / 2;
    svgPath.y = 42;
    svgPath.b = 0;
    svgPath.a = width;

    // $(document).on('mousemove touchmove', e => {
    //     if(handle) {

    //         let laziness = 4,
    //             max = 24,
    //             edge = 52,
    //             other = handleObj.eq(handle.data('index') == 0 ? 1 : 0),
    //             currentLeft = handle.position().left,
    //             otherLeft = other.position().left,
    //             handleWidth = handle.outerWidth(),
    //             handleHalf = handleWidth / 2,
    //             y = e.pageY - handle.offset().top - handle.outerHeight() / 2,
    //             moveY = (y - laziness >= 0) ? y - laziness : (y + laziness <= 0) ? y + laziness : 0,
    //             modify = 1;

    //         moveY = (moveY > max) ? max : (moveY < -max) ? -max : moveY;
    //         modify = handle.data('index') == 0 ? ((currentLeft + handleHalf <= edge ? (currentLeft + handleHalf) / edge : 1) * (otherLeft - currentLeft - handleWidth <= edge ? (otherLeft - currentLeft - handleWidth) / edge : 1)) : ((currentLeft - (otherLeft + handleHalf * 2) <= edge ? (currentLeft - (otherLeft + handleWidth)) / edge : 1) * (slider.outerWidth() - (currentLeft + handleHalf) <= edge ? (slider.outerWidth() - (currentLeft + handleHalf)) / edge : 1));
    //         modify = modify > 1 ? 1 : modify < 0 ? 0 : modify;

    //         if(handle.data('index') == 0) {
    //             svgPath.b = currentLeft / 2  * modify;
    //             svgPath.a = otherLeft;
    //         } else {
    //             svgPath.b = otherLeft + handleHalf;
    //             svgPath.a = (slider.outerWidth() - currentLeft) / 2 + currentLeft + handleHalf + ((slider.outerWidth() - currentLeft) / 2) * (1 - modify);
    //         }

    //         svgPath.x = currentLeft + handleHalf;
    //         svgPath.y = moveY * modify + 42;

    //         handle.css('--y', moveY * modify);

    //     }
    // });

});

function getPoint(point, i, a, smoothing) {
    let cp = (current, previous, next, reverse) => {
            let p = previous || current,
                n = next || current,
                o = {
                    length: Math.sqrt(Math.pow(n[0] - p[0], 2) + Math.pow(n[1] - p[1], 2)),
                    angle: Math.atan2(n[1] - p[1], n[0] - p[0])
                },
                angle = o.angle + (reverse ? Math.PI : 0),
                length = o.length * smoothing;
            return [current[0] + Math.cos(angle) * length, current[1] + Math.sin(angle) * length];
        },
        cps = cp(a[i - 1], a[i - 2], point, false),
        cpe = cp(point, a[i - 1], a[i + 1], true);
    return `C ${cps[0]},${cps[1]} ${cpe[0]},${cpe[1]} ${point[0]},${point[1]}`;
}

function getPath(update, before, after, width) {
    let smoothing = .16,
        points = [
            [0, 42],
            [before <= 0 ? 0 : before, 42],
            update,
            [after >= width ? width : after, 42],
            [width, 42]
        ],
        d = points.reduce((acc, point, i, a) => i === 0 ? `M ${point[0]},${point[1]}` : `${acc} ${getPoint(point, i, a, smoothing)}`, '');
    return `<path d="${d}" />`;
}

function setCSSVars(slider) {
    let handle = slider.find('.ui-slider-handle');
    slider.css({
        '--l': handle.eq(0).position().left + handle.eq(0).outerWidth() / 2,
        '--r': slider.outerWidth() - (handle.eq(1).position().left + handle.eq(1).outerWidth() / 2)
    });
}


//#endregion Filter Car Price End




function getCount(parent, getChildrensChildren){
    var relevantChildren = 0;
    var children = parent.childNodes.length;
    for(var i=0; i < children; i++){
        if(parent.childNodes[i].nodeType != 3){
            if(getChildrensChildren)
                relevantChildren += getCount(parent.childNodes[i],true);
            relevantChildren++;
        }
    }
    return relevantChildren;
}


const All_road = document.getElementById('All_road');
const Sedan = document.getElementById('Sedan');
const Hatchback = document.getElementById('Hatchback');
const Liftback = document.getElementById('Liftback');
const Wagon = document.getElementById('Wagon');
const Minivan = document.getElementById('Minivan');
const Coupe = document.getElementById('Coupe');
const Pickup = document.getElementById('Pickup');
const Cabrio = document.getElementById('Cabrio');
const Van = document.getElementById('Van');

let All_roadFilter = false;
let SedanFilter = false;
let HatchbackFilter = false;
let LiftbackFilter = false;
let WagonFilter = false;
let MinivanFilter = false;
let CoupeFilter = false;
let PickupFilter = false;
let CabrioFilter = false;
let VanFilter = false;

Hatchback.addEventListener('click', () => {
    if (!HatchbackFilter){
        Hatchback.style.backgroundColor = "#fdfdfd";
        Hatchback.style.border = '0.5px solid rgb(203, 203, 203)';
        Hatchback.style.borderRadius = "7px";

        HatchbackFilter = true;
    }
    else{

        Hatchback.style.backgroundColor = "white";
        Hatchback.style.border = 'none';
        Hatchback.style.borderRadius = "7px";

        HatchbackFilter = false;
    }
});
Van.addEventListener('click', () => {
    if (!VanFilter){
        Van.style.backgroundColor = "#fdfdfd";
        Van.style.border = '0.5px solid rgb(203, 203, 203)';
        Van.style.borderRadius = "7px";
        VanFilter = true;
    }
    else{

        Van.style.backgroundColor = "white";
        Van.style.border = 'none';
        Van.style.borderRadius = "7px";

        VanFilter = false;
    }
});
Cabrio.addEventListener('click', () => {
    if (!CabrioFilter){
        Cabrio.style.backgroundColor = "#fdfdfd";
        Cabrio.style.border = '0.5px solid rgb(203, 203, 203)';
        Cabrio.style.borderRadius = "7px";
        CabrioFilter = true;
    }
    else{

        Cabrio.style.backgroundColor = "white";
        Cabrio.style.border = 'none';
        Cabrio.style.borderRadius = "7px";

        CabrioFilter = false;
    }
});
Pickup.addEventListener('click', () => {
    if (!PickupFilter){
        Pickup.style.backgroundColor = "#fdfdfd";
        Pickup.style.border = '0.5px solid rgb(203, 203, 203)';
        Pickup.style.borderRadius = "7px";
        PickupFilter = true;
    }
    else{

        Pickup.style.backgroundColor = "white";
        Pickup.style.border = 'none';
        Pickup.style.borderRadius = "7px";

        PickupFilter = false;
    }
});
Coupe.addEventListener('click', () => {
    if (!CoupeFilter){
        Coupe.style.backgroundColor = "#fdfdfd";
        Coupe.style.border = '0.5px solid rgb(203, 203, 203)';
        Coupe.style.borderRadius = "7px";
        CoupeFilter = true;
    }
    else{

        Coupe.style.backgroundColor = "white";
        Coupe.style.border = 'none';
        Coupe.style.borderRadius = "7px";

        CoupeFilter = false;
    }
});
Minivan.addEventListener('click', () => {
    if (!MinivanFilter){
        Minivan.style.backgroundColor = "#fdfdfd";
        Minivan.style.border = '0.5px solid rgb(203, 203, 203)';
        Minivan.style.borderRadius = "7px";
        MinivanFilter = true;
    }
    else{

        Minivan.style.backgroundColor = "white";
        Minivan.style.border = 'none';
        Minivan.style.borderRadius = "7px";

        MinivanFilter = false;
    }
});
Wagon.addEventListener('click', () => {
    if (!WagonFilter){
        Wagon.style.backgroundColor = "#fdfdfd";
        Wagon.style.border = '0.5px solid rgb(203, 203, 203)';
        Wagon.style.borderRadius = "7px";
        WagonFilter = true;
    }
    else{

        Wagon.style.backgroundColor = "white";
        Wagon.style.border = 'none';
        Wagon.style.borderRadius = "7px";

        WagonFilter = false;
    }
});
Liftback.addEventListener('click', () => {
    if (!LiftbackFilter){
        Liftback.style.backgroundColor = "#fdfdfd";
        Liftback.style.border = '0.5px solid rgb(203, 203, 203)';
        Liftback.style.borderRadius = "7px";
        LiftbackFilter = true;
    }
    else{

        Liftback.style.backgroundColor = "white";
        Liftback.style.border = 'none';
        Liftback.style.borderRadius = "7px";

        LiftbackFilter = false;
    }
});
All_road.addEventListener('click', () => {
    if (!All_roadFilter){
        All_road.style.backgroundColor = "#fdfdfd";
        All_road.style.border = '0.5px solid rgb(203, 203, 203)';
        All_road.style.borderRadius = "7px";
        All_roadFilter = true;
    }
    else{

        All_road.style.backgroundColor = "white";
        All_road.style.border = 'none';
        All_road.style.borderRadius = "7px";

        All_roadFilter = false;
    }
});
Sedan.addEventListener('click', () => {
    if (!SedanFilter){
        Sedan.style.backgroundColor = "#fdfdfd";
        Sedan.style.border = '0.5px solid rgb(203, 203, 203)';
        Sedan.style.borderRadius = "7px";
        SedanFilter = true;
    }
    else{

        Sedan.style.backgroundColor = "white";
        Sedan.style.border = 'none';
        Sedan.style.borderRadius = "7px";

        SedanFilter = false;
    }
});

const leftBtnFilter = document.getElementById('leftBtnFilter');
const middleBtnFilter = document.getElementById('middleBtnFilter');
const rightBtnFilter = document.getElementById('rightBtnFilter');

let NewOldAll = 1;

leftBtnFilter.addEventListener('click', () => {
    if (NewOldAll != 1)
    {
        leftBtnFilter.classList.add('active');
        middleBtnFilter.classList.remove('active');
        rightBtnFilter.classList.remove('active');
        
        NewOldAll = 1;
    }
});
middleBtnFilter.addEventListener('click', () => {
    if (NewOldAll != 2)
    {
        leftBtnFilter.classList.remove('active');
        middleBtnFilter.classList.add('active');
        rightBtnFilter.classList.remove('active');

        NewOldAll = 2;
    }
});
rightBtnFilter.addEventListener('click', () => {
    if (NewOldAll != 3)
    {
        leftBtnFilter.classList.remove('active');
        middleBtnFilter.classList.remove('active');
        rightBtnFilter.classList.add('active');

        NewOldAll = 3;
    }
});





const Cars_Logo_Marks = document.querySelector('.Cars_Logo_Marks');
const Cars_List_Place = document.querySelector('.Cars_List_Place');
// Top_Cars_List_All_Cars

let Stamps_IsOpen = true;

const leftBtnHelper = document.getElementById('leftBtnHelper');
const rightBtnHelper = document.getElementById('rightBtnHelper');

const Cars_Helper_Mode_Place = document.querySelector('.Cars_Helper_Mode_Place');

rightBtnHelper.addEventListener('click', () => {
    if (Stamps_IsOpen) {

        Cars_Helper_Mode_Place.classList.remove('d-none');
        Cars_Logo_Marks.classList.add('d-none');
        // Top_Cars_List_All_Cars.classList.add('d-none');
        Cars_List_Place.classList.add('d-none');
        rightBtnHelper.classList.add('active');
        leftBtnHelper.classList.remove('active');
        Stamps_IsOpen = false;
    }
});

leftBtnHelper.addEventListener('click', () => {
    if (!Stamps_IsOpen) {
        Cars_Logo_Marks.classList.remove('d-none');
        // Top_Cars_List_All_Cars.classList.remove('d-none');
        Cars_List_Place.classList.remove('d-none');
        Cars_Helper_Mode_Place.classList.add('d-none');
        leftBtnHelper.classList.add('active');
        rightBtnHelper.classList.remove('active');
        Stamps_IsOpen = true;
    }
});



const Spacious = document.getElementById('Spacious');
const Quickly = document.getElementById('Quickly');
const Economical = document.getElementById('Economical');
const Passable = document.getElementById('Passable');
let SpaciousFilter = false;
let QuicklyFilter = false;
let EconomicalFilter = false;
let PassableFilter = false;


Spacious.addEventListener('click', () => {
    if (!SpaciousFilter){
        Spacious.style.backgroundColor = "#dzdzdz";
        Spacious.style.borderColor = "#2284ef";
        Spacious.style.borderColor = "#2284ef";
        Spacious.classList.add('Assistant_Car_Filter_Blue')
        SpaciousFilter = true;
    }
    else{

        Spacious.style.backgroundColor = "white";
        Spacious.style.borderColor = "rgb(221, 221, 221)"
        Spacious.classList.remove('Assistant_Car_Filter_Blue')

        SpaciousFilter = false;
    }
});
Quickly.addEventListener('click', () => {
    if (!QuicklyFilter){
        Quickly.style.backgroundColor = "#dzdzdz";
        Quickly.style.borderColor = "#2284ef";
        Quickly.style.borderColor = "#2284ef";
        Quickly.classList.add('Assistant_Car_Filter_Blue')
        QuicklyFilter = true;
    }
    else{

        Quickly.style.backgroundColor = "white";
        Quickly.style.borderColor = "rgb(221, 221, 221)"

        Quickly.classList.remove('Assistant_Car_Filter_Blue')
        QuicklyFilter = false;
    }
});
Economical.addEventListener('click', () => {
    if (!EconomicalFilter){
        Economical.style.backgroundColor = "#dzdzdz";
        Economical.style.borderColor = "#2284ef";
        Economical.style.borderColor = "#2284ef";
        Economical.classList.add('Assistant_Car_Filter_Blue')
        EconomicalFilter = true;
    }
    else{

        Economical.style.backgroundColor = "white";
        Economical.style.borderColor = "rgb(221, 221, 221)"

        Economical.classList.remove('Assistant_Car_Filter_Blue')
        EconomicalFilter = false;
    }
});
Passable.addEventListener('click', () => {
    if (!PassableFilter){
        Passable.style.backgroundColor = "#dzdzdz";
        Passable.style.borderColor = "#2284ef";
        Passable.style.borderColor = "#2284ef";
        Passable.classList.add('Assistant_Car_Filter_Blue')
        PassableFilter = true;
    }
    else{

        Passable.style.backgroundColor = "white";
        Passable.style.borderColor = "rgb(221, 221, 221)"

        Passable.classList.remove('Assistant_Car_Filter_Blue')
        PassableFilter = false;
    }
});



const New_discounted = document.getElementById('New_discounted');
const Special_Offers = document.getElementById('Special_Offers');
const Lower_Price = document.getElementById('Lower_Price');

let CollectionsButton = 1;

const New_Discounted_Page = document.getElementById('New_Discounted_Page');
const Special_Offers_Page = document.getElementById('Special_Offers_Page');
const Lower_Price_Page = document.getElementById('Lower_Price_Page');


New_discounted.addEventListener('click', () => {
    if (CollectionsButton != 1)
    {
        New_discounted.classList.add('active');
        Special_Offers.classList.remove('active');
        Lower_Price.classList.remove('active');
        
        
        New_Discounted_Page.classList.remove('d-none');
        Special_Offers_Page.classList.add('d-none');
        Lower_Price_Page.classList.add('d-none');

        CollectionsButton = 1;
    }
});
Special_Offers.addEventListener('click', () => {
    if (CollectionsButton != 2)
    {
        New_discounted.classList.remove('active');
        Special_Offers.classList.add('active');
        Lower_Price.classList.remove('active');

        New_Discounted_Page.classList.add('d-none');
        Special_Offers_Page.classList.remove('d-none');
        Lower_Price_Page.classList.add('d-none');

        CollectionsButton = 2;
    }
});
Lower_Price.addEventListener('click', () => {
    if (CollectionsButton != 3)
    {
        New_discounted.classList.remove('active');
        Special_Offers.classList.remove('active');  
        Lower_Price.classList.add('active');

        New_Discounted_Page.classList.add('d-none');
        Special_Offers_Page.classList.add('d-none');
        Lower_Price_Page.classList.remove('d-none');

        CollectionsButton = 3;
    }
});

$(document).ready(function(){
    $(".owl-carousel").owlCarousel({
        items:4,
        responsiveClass:true,
        responsive:{
            0:{
                items:1,
            },
            399:{
                items:1,
                margin:-100,
            },
            488:{
                items:1,
                margin:-200,
            },
            600:{
                items:2,
            },
            900:{
                items:2,
                margin:-50,
            },
            997:{
                items:3,
                margin:-50,
            },
            1200:{
                items:4,
            },
            1500:{
                items:4,
                margin:-120,
            },
        }
    });
  });4






const All_rubrics = document.getElementById('All_rubrics');
const Tests = document.getElementById('Tests');
const News = document.getElementById('News');
const Parsing = document.getElementById('Parsing');
const Collections = document.getElementById('Collections');
const About_business = document.getElementById('About_business');
const Travels = document.getElementById('Travels');

const Journal_Cards_All_Rubrics = document.getElementById('Journal_Cards_All_Rubrics');
const Journal_Cards_Tests = document.getElementById('Journal_Cards_Tests');
const Journal_Cards_News = document.getElementById('Journal_Cards_News');
const Journal_Cards_Parsing = document.getElementById('Journal_Cards_Parsing');
const Journal_Cards_Collections = document.getElementById('Journal_Cards_Collections');
const Journal_Cards_About_business = document.getElementById('Journal_Cards_About_business');
const Journal_Cards_Travels = document.getElementById('Journal_Cards_Travels');

let JournalFilterButton = 1;

All_rubrics.addEventListener('click', () => {
    if (JournalFilterButton != 1)
    {
        All_rubrics.classList.add('active');
        Tests.classList.remove('active');
        News.classList.remove('active');
        Parsing.classList.remove('active');
        Collections.classList.remove('active');
        About_business.classList.remove('active');
        Travels.classList.remove('active');

        Journal_Cards_All_Rubrics.classList.remove('d-none')
        Journal_Cards_Tests.classList.add('d-none')
        Journal_Cards_News.classList.add('d-none')
        Journal_Cards_Parsing.classList.add('d-none')
        Journal_Cards_Collections.classList.add('d-none')
        Journal_Cards_About_business.classList.add('d-none')
        Journal_Cards_Travels.classList.add('d-none')

        JournalFilterButton = 1;
    }
});
Tests.addEventListener('click', () => {
    if (JournalFilterButton != 2)
    {
        All_rubrics.classList.remove('active');
        Tests.classList.add('active');
        News.classList.remove('active');
        Parsing.classList.remove('active');
        Collections.classList.remove('active');
        About_business.classList.remove('active');
        Travels.classList.remove('active');

        Journal_Cards_All_Rubrics.classList.add('d-none')
        Journal_Cards_Tests.classList.remove('d-none')
        Journal_Cards_News.classList.add('d-none')
        Journal_Cards_Parsing.classList.add('d-none')
        Journal_Cards_Collections.classList.add('d-none')
        Journal_Cards_About_business.classList.add('d-none')
        Journal_Cards_Travels.classList.add('d-none')

        JournalFilterButton = 2;
    }
});
News.addEventListener('click', () => {
    if (JournalFilterButton != 3)
    {
        All_rubrics.classList.remove('active');
        Tests.classList.remove('active');
        News.classList.add('active');
        Parsing.classList.remove('active');
        Collections.classList.remove('active');
        About_business.classList.remove('active');
        Travels.classList.remove('active');

        Journal_Cards_All_Rubrics.classList.add('d-none')
        Journal_Cards_Tests.classList.add('d-none')
        Journal_Cards_News.classList.remove('d-none')
        Journal_Cards_Parsing.classList.add('d-none')
        Journal_Cards_Collections.classList.add('d-none')
        Journal_Cards_About_business.classList.add('d-none')
        Journal_Cards_Travels.classList.add('d-none')

        JournalFilterButton = 3;
    }
});
Parsing.addEventListener('click', () => {
    if (JournalFilterButton != 4)
    {
        All_rubrics.classList.remove('active');
        Tests.classList.remove('active');
        News.classList.remove('active');
        Parsing.classList.add('active');
        Collections.classList.remove('active');
        About_business.classList.remove('active');
        Travels.classList.remove('active');

        Journal_Cards_All_Rubrics.classList.add('d-none')
        Journal_Cards_Tests.classList.add('d-none')
        Journal_Cards_News.classList.add('d-none')
        Journal_Cards_Parsing.classList.remove('d-none')
        Journal_Cards_Collections.classList.add('d-none')
        Journal_Cards_About_business.classList.add('d-none')
        Journal_Cards_Travels.classList.add('d-none')

        JournalFilterButton = 4;
    }
});
Collections.addEventListener('click', () => {
    if (JournalFilterButton != 5)
    {
        All_rubrics.classList.remove('active');
        Tests.classList.remove('active');
        News.classList.remove('active');
        Parsing.classList.remove('active');
        Collections.classList.add('active');
        About_business.classList.remove('active');
        Travels.classList.remove('active');

        Journal_Cards_All_Rubrics.classList.add('d-none')
        Journal_Cards_Tests.classList.add('d-none')
        Journal_Cards_News.classList.add('d-none')
        Journal_Cards_Parsing.classList.add('d-none')
        Journal_Cards_Collections.classList.remove('d-none')
        Journal_Cards_About_business.classList.add('d-none')
        Journal_Cards_Travels.classList.add('d-none')

        JournalFilterButton = 5;
    }
});
About_business.addEventListener('click', () => {
    if (CollectionsButton != 6)
    {
        All_rubrics.classList.remove('active');
        Tests.classList.remove('active');
        News.classList.remove('active');
        Parsing.classList.remove('active');
        Collections.classList.remove('active');
        About_business.classList.add('active');
        Travels.classList.remove('active');

        Journal_Cards_All_Rubrics.classList.add('d-none')
        Journal_Cards_Tests.classList.add('d-none')
        Journal_Cards_News.classList.add('d-none')
        Journal_Cards_Parsing.classList.add('d-none')
        Journal_Cards_Collections.classList.add('d-none')
        Journal_Cards_About_business.classList.remove('d-none')
        Journal_Cards_Travels.classList.add('d-none')

        JournalFilterButton = 6;
    }
});
Travels.addEventListener('click', () => {
    if (JournalFilterButton != 7)
    {
        All_rubrics.classList.remove('active');
        Tests.classList.remove('active');
        News.classList.remove('active');
        Parsing.classList.remove('active');
        Collections.classList.remove('active');
        About_business.classList.remove('active');
        Travels.classList.add('active');

        Journal_Cards_All_Rubrics.classList.add('d-none')
        Journal_Cards_Tests.classList.add('d-none')
        Journal_Cards_News.classList.add('d-none')
        Journal_Cards_Parsing.classList.add('d-none')
        Journal_Cards_Collections.classList.add('d-none')
        Journal_Cards_About_business.classList.add('d-none')
        Journal_Cards_Travels.classList.remove('d-none')

        JournalFilterButton = 7;
    }
});


var x, i, j, l, ll, selElmnt, a, b, c;
/*look for any elements with the class "custom-select":*/
x = document.getElementsByClassName("custom-select");
l = x.length;
for (i = 0; i < l; i++) {
  selElmnt = x[i].getElementsByTagName("select")[0];
  ll = selElmnt.length;
  /*for each element, create a new DIV that will act as the selected item:*/
  a = document.createElement("DIV");
  a.setAttribute("class", "select-selected");
  a.innerHTML = selElmnt.options[selElmnt.selectedIndex].innerHTML;
  x[i].appendChild(a);
  /*for each element, create a new DIV that will contain the option list:*/
  b = document.createElement("DIV");
  b.setAttribute("class", "select-items select-hide");
  for (j = 1; j < ll; j++) {
    /*for each option in the original select element,
    create a new DIV that will act as an option item:*/
    c = document.createElement("DIV");
    c.innerHTML = selElmnt.options[j].innerHTML;
    c.addEventListener("click", function(e) {
        /*when an item is clicked, update the original select box,
        and the selected item:*/
        var y, i, k, s, h, sl, yl;
        s = this.parentNode.parentNode.getElementsByTagName("select")[0];
        sl = s.length;
        h = this.parentNode.previousSibling;
        for (i = 0; i < sl; i++) {
          if (s.options[i].innerHTML == this.innerHTML) {
            s.selectedIndex = i;
            h.innerHTML = this.innerHTML;
            y = this.parentNode.getElementsByClassName("same-as-selected");
            yl = y.length;
            for (k = 0; k < yl; k++) {
              y[k].removeAttribute("class");
            }
            this.setAttribute("class", "same-as-selected");
            break;
          }
        }
        h.click();
    });
    b.appendChild(c);
  }
  x[i].appendChild(b);
  a.addEventListener("click", function(e) {
      /*when the select box is clicked, close any other select boxes,
      and open/close the current select box:*/
      e.stopPropagation();
      closeAllSelect(this);
      this.nextSibling.classList.toggle("select-hide");
      this.classList.toggle("select-arrow-active");
    });
}
function closeAllSelect(elmnt) {
  /*a function that will close all select boxes in the document,
  except the current select box:*/
  var x, y, i, xl, yl, arrNo = [];
  x = document.getElementsByClassName("select-items");
  y = document.getElementsByClassName("select-selected");
  xl = x.length;
  yl = y.length;
  for (i = 0; i < yl; i++) {
    if (elmnt == y[i]) {
      arrNo.push(i)
    } else {
      y[i].classList.remove("select-arrow-active");
    }
  }
  for (i = 0; i < xl; i++) {
    if (arrNo.indexOf(i)) {
      x[i].classList.add("select-hide");
    }
  }
}
/*if the user clicks anywhere outside the select box,
then close all select boxes:*/
document.addEventListener("click", closeAllSelect);